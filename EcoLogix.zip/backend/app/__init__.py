"""EcoLogix Backend App Package"""
